************
Courses
************

.. image:: _img/mainpage/online.png

* **Machine Learning** by Stanford on Coursera :
  [`Link <https://www.coursera.org/learn/machine-learning>`_]

* **Neural Networks and Deep Learning** Specialization by Coursera:
  [`Link <https://www.coursera.org/learn/neural-networks-deep-learning>`_]

* **Intro to Deep Learning** by Google:
  [`Link <https://www.udacity.com/course/deep-learning--ud730>`_]

* **NVIDIA Deep Learning Institute** by NVIDIA:
  [`Link <https://www.nvidia.com/en-us/deep-learning-ai/education/>`_]

* **Convolutional Neural Networks for Visual Recognition** by Standford:
  [`Link <http://cs231n.stanford.edu/>`_]

* **Deep Learning for Natural Language Processing** by Standford:
  [`Link <http://cs224d.stanford.edu/>`_]

* **Deep Learning** by fast.ai:
  [`Link <http://www.fast.ai/>`_]
