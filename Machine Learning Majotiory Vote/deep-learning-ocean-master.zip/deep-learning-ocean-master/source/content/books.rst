************
Books
************

.. image:: _img/mainpage/books.jpg

* **Deep Learning** by Ian Goodfellow:
  [`Link <http://www.deeplearningbook.org/>`_]

* **Neural Networks and Deep Learning** :
  [`Link <http://neuralnetworksanddeeplearning.com/>`_]

* **Deep Learning with Python**:
  [`Link <https://www.amazon.com/Deep-Learning-Python-Francois-Chollet/dp/1617294438/ref=as_li_ss_tl?s=books&ie=UTF8&qid=1519989624&sr=1-4&keywords=deep+learning+with+python&linkCode=sl1&tag=trndingcom-20&linkId=ec7663329fdb7ace60f39c762e999683>`_]

* **Hands-On Machine Learning with Scikit-Learn and TensorFlow: Concepts, Tools, and Techniques to Build Intelligent Systems**:
  [`Link <https://www.amazon.com/Hands-Machine-Learning-Scikit-Learn-TensorFlow/dp/1491962291/ref=as_li_ss_tl?ie=UTF8&qid=1519989725&sr=1-2-ent&linkCode=sl1&tag=trndingcom-20&linkId=71938c9398940c7b0a811dc1cfef7cc3>`_]
