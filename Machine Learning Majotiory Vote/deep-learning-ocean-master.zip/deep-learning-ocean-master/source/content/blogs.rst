************
Blogs
************

.. image:: _img/mainpage/Blogger_icon.png

* **Colah's blog**:
  [`Link <http://colah.github.io/>`_]

* **Andrej Karpathy blog**:
  [`Link <http://karpathy.github.io/>`_]

* **The Spectator** Shakir's Machine Learning Blog:
  [`Link <http://blog.shakirm.com/>`_]

* **WILDML**:
  [`Link <http://www.wildml.com/about/>`_]

* **Distill blog**:
  [`Link <https://distill.pub/>`_]

* **BAIR** Berkeley Artificial Intelligent Research:
  [`Link <http://bair.berkeley.edu/blog/>`_]

* **Sebastian Ruder's blog**:
  [`Link <http://ruder.io/>`_]

* **inFERENCe**:
  [`Link <https://www.inference.vc/page/2/>`_]

* **i am trask** A Machine Learning Craftsmanship Blog:
  [`Link <http://iamtrask.github.io>`_]
