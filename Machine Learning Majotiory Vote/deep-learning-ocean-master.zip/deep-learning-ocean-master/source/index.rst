.. TensoFlow-World-Resources documentation master file, created by
   sphinx-quickstart on Wed Jul  5 16:28:45 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to Deep Learning NLP documentation!
=====================================================

.. toctree::
   :maxdepth: 2
   :caption: Foreword
   
   intro/intro

.. toctree::
   :maxdepth: 2
   :caption: Content
   
   content/papers
   content/courses
   content/books
   content/blogs
   content/tutorials

.. toctree::
   :maxdepth: 2
   :caption: Document Credentials

   
   credentials/CONTRIBUTING
   credentials/CODE_OF_CONDUCT
   credentials/LICENSE




