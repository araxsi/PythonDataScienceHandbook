***************
Introduction
***************

The purpose of this project is to introduce a shortcut to developers and researcher
for finding useful resources about Deep Learning for Natural Language Processing.

============
Motivation
============

There are different motivations for this open source project.

.. --------------------
.. Why Deep Learning?
.. --------------------

------------------------------------------------------------
What's the point of this open source project?
------------------------------------------------------------

There other similar repositories similar to this repository and are very
comprehensive and useful and to be honest they made me ponder if there is
a necessity for this repository!

**The point of this repository is that the resources are being targeted**. The organization
of the resources is such that the user can easily find the things he/she is looking for.
We divided the resources to a large number of categories that in the beginning one may
have a headache!!! However, if someone knows what is being located, it is very easy to find the most related resources.
Even if someone doesn't know what to look for, in the beginning, the general resources have
been provided.
